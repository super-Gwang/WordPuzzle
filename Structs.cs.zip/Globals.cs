public static class Globals
{
    public const int ROW_LEN = 6, COL_LEN = 5;
}
